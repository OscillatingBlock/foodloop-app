#retailer_roues.py
from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required, get_jwt_identity
from .models import db, User, InventoryItem, FoodRequest, Food
from datetime import datetime

retailer_bp = Blueprint("retailer", __name__, url_prefix="/retailers")


@retailer_bp.route("/inventory", methods=["GET"])
@jwt_required()
def get_inventory():
    # Get the current user email from the JWT token
    current_user_email = get_jwt_identity()
    user = User.query.filter_by(email=current_user_email).first()

    if not user:
        return jsonify({"error": "User not found"}), 404

    # Fetch the user's inventory items
    inventory = InventoryItem.query.filter_by(user_id=user.id).all()
    return jsonify(
        [
            {
                "id": item.id,
                "name": item.food.name,
                "quantity": item.food.quantity,
                "expiry_date": item.food.expiry_date.isoformat(),
                "created_at": item.food.created_at.isoformat(),
            }
            for item in inventory
        ]
    )

@retailer_bp.route("/add_item", methods=["POST"])
@jwt_required()
def add_inventory_item():
    current_user_email = get_jwt_identity()
    user = User.query.filter_by(email=current_user_email).first()

    if not user:
        return jsonify({"error": "User not found"}), 404

    data = request.get_json()

    if not data.get("name") or not data.get("quantity") or not data.get("expiry_date"):
        return jsonify({"error": "Missing required fields"}), 422

    try:
        quantity = float(data["quantity"])
        if quantity <= 0:
            return jsonify({"error": "Quantity must be greater than 0"}), 422
    except ValueError:
        return jsonify({"error": "Invalid quantity"}), 422

    try:
        food = Food(
            name=data["name"],
            quantity=quantity,
            expiry_date=datetime.fromisoformat(data["expiry_date"].replace("Z", "+00:00")),
        )
        db.session.add(food)
        db.session.flush()  # Get food.id before commit

        new_item = InventoryItem(
            user_id=user.id,
            food_id=food.id
        )

        db.session.add(new_item)
        db.session.commit()

        return jsonify({
            "id": new_item.id,
            "name": food.name,
            "quantity": food.quantity,
            "expiry_date": food.expiry_date.isoformat(),
        }), 201

    except Exception as e:
        db.session.rollback()
        print(f"Error occurred while adding item: {str(e)}")
        return jsonify({"error": str(e)}), 400


@retailer_bp.route("/requested_food", methods=["GET"])
@jwt_required()
def get_food_requests():
    current_user_email = get_jwt_identity()
    user = User.query.filter_by(email=current_user_email).first()

    if not user:
        return jsonify({"error": "User not found"}), 404

    requests = (
        FoodRequest.query.join(InventoryItem)
        .filter(InventoryItem.user_id == user.id)
        .all()
    )

    return jsonify([
        {
            "id": req.id,
            "inventory_item": {
                "id": req.inventory_item.id,
                "name": req.inventory_item.food.name,
                "quantity": req.inventory_item.food.quantity,
            },
            "status": req.status,
            "created_at": req.created_at.isoformat(),
        }
        for req in requests
    ])
