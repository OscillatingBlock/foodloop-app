# retailer_routes.py
from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required, get_jwt_identity
from .models import db, User, InventoryItem, FoodRequest, Food
from datetime import datetime

retailer_bp = Blueprint("retailer", __name__, url_prefix="/retailers")

@retailer_bp.route("/inventory", methods=["GET"])
@jwt_required()
def get_inventory():
    current_user_email = get_jwt_identity()
    user = User.query.filter_by(email=current_user_email).first()

    if not user:
        return jsonify({"error": "User not found"}), 404

    inventory = InventoryItem.query.filter_by(user_id=user.id).all()
    return jsonify(
        [
            {
                "id": item.id,
                "name": item.food.name,
                "quantity": item.food.quantity,
                "best_before": item.food.expiry_date.isoformat(),  # Assuming expiry_date is best_before for now
                "expires_at": item.food.expiry_date.isoformat(),    # Update model if separate dates needed
                "status": item.food.status if hasattr(item.food, "status") else "Selling",
                "created_at": item.food.created_at.isoformat(),
            }
            for item in inventory
        ]
    )

@retailer_bp.route("/add_item", methods=["POST"])
@jwt_required()
def add_inventory_item():
    current_user_email = get_jwt_identity()
    user = User.query.filter_by(email=current_user_email).first()

    if not user:
        return jsonify({"error": "User not found"}), 404

    data = request.get_json()

    required_fields = ["name", "quantity", "best_before", "expires_at"]
    if not all(field in data for field in required_fields):
        return jsonify({"error": "Missing required fields"}), 422

    try:
        quantity = float(data["quantity"])
        if quantity <= 0:
            return jsonify({"error": "Quantity must be greater than 0"}), 422
    except ValueError:
        return jsonify({"error": "Invalid quantity"}), 422

    try:
        best_before = datetime.fromisoformat(data["best_before"].replace("Z", "+00:00"))
        expires_at = datetime.fromisoformat(data["expires_at"].replace("Z", "+00:00"))

        if best_before >= expires_at or best_before < datetime.utcnow():
            return jsonify({"error": "Invalid date range"}), 422

        food = Food(
            name=data["name"],
            quantity=quantity,
            best_before=best_before,
            expires_at=expires_at,
            created_at=datetime.utcnow(),
            status="Selling"
        )
        db.session.add(food)
        db.session.flush()

        new_item = InventoryItem(user_id=user.id, food_id=food.id)
        db.session.add(new_item)
        db.session.commit()

        return jsonify({
            "id": new_item.id,
            "name": food.name,
            "quantity": food.quantity,
            "best_before": data["best_before"],
            "expires_at": data["expires_at"],
            "status": food.status,
        }), 201

    except Exception as e:
        db.session.rollback()
        return jsonify({"error": str(e)}), 400


@retailer_bp.route("/requested_food", methods=["GET"])
@jwt_required()
def get_food_requests():
    current_user_email = get_jwt_identity()
    user = User.query.filter_by(email=current_user_email).first()

    if not user:
        return jsonify({"error": "User not found"}), 404

    requests = FoodRequest.query.join(InventoryItem).filter(InventoryItem.user_id == user.id).all()
    return jsonify([
        {
            "id": req.id,
            "food_id": req.inventory_item.food_id,
            "ngo_id": req.requester_id,
            "quantity": req.quantity if hasattr(req, "quantity") else req.inventory_item.food.quantity,
            "status": req.status,
            "pickup_date": req.pickup_date.isoformat() if req.pickup_date else None,
            "created_at": req.created_at.isoformat(),
        }
        for req in requests
    ])

@retailer_bp.route("/inventory/<int:id>/sell", methods=["POST"])
@jwt_required()
def sell_inventory_item(id):
    current_user_email = get_jwt_identity()
    user = User.query.filter_by(email=current_user_email).first()

    if not user:
        return jsonify({"error": "User not found"}), 404

    item = InventoryItem.query.filter_by(id=id, user_id=user.id).first()
    if not item:
        return jsonify({"error": "Inventory item not found"}), 404

    data = request.get_json()
    if not data.get("quantity"):
        return jsonify({"error": "Quantity is required"}), 422

    try:
        quantity_to_sell = float(data["quantity"])
        if quantity_to_sell <= 0:
            return jsonify({"error": "Quantity must be greater than 0"}), 422
        if quantity_to_sell > item.food.quantity:
            return jsonify({"error": "Insufficient quantity"}), 422

        current_date = datetime.utcnow()
        if current_date > item.food.expiry_date:  # Assuming expiry_date is best_before for now
            return jsonify({"error": "Cannot sell after expiry date"}), 422

        item.food.quantity -= quantity_to_sell
        db.session.commit()

        return jsonify({
            "message": f"Sold {quantity_to_sell} of {item.food.name}",
            "remaining_quantity": item.food.quantity
        }), 200

    except Exception as e:
        db.session.rollback()
        return jsonify({"error": str(e)}), 400

@retailer_bp.route("/inventory/<int:id>/list", methods=["POST"])
@jwt_required()
def list_inventory_item(id):
    current_user_email = get_jwt_identity()
    user = User.query.filter_by(email=current_user_email).first()

    if not user:
        return jsonify({"error": "User not found"}), 404

    item = InventoryItem.query.filter_by(id=id, user_id=user.id).first()
    if not item or item.food.quantity <= 0:
        return jsonify({"error": "Inventory item not found or no quantity available"}), 404

    current_date = datetime.utcnow()
    if current_date < item.food.expiry_date:  # Assuming expiry_date is best_before for now
        return jsonify({"error": "Cannot list before expiry date"}), 422

    item.food.status = "Listing"
    db.session.commit()

    return jsonify({"message": "Food listed for NGOs"}), 200

@retailer_bp.route("/notifications", methods=["GET"])
@jwt_required()
def get_notifications():
    current_user_email = get_jwt_identity()
    user = User.query.filter_by(email=current_user_email).first()

    if not user:
        return jsonify({"error": "User not found"}), 404

    # Mock notifications (replace with actual logic or database table)
    inventory = InventoryItem.query.filter_by(user_id=user.id).all()
    notifications = []
    current_date = datetime.utcnow()
    for item in inventory:
        if item.food.quantity > 0 and item.food.status == "Selling" and current_date > item.food.expiry_date:
            notifications.append({
                "id": item.id,
                "message": f"Your {item.food.name} (remaining: {item.food.quantity}) is past best before. List it or ignore.",
                "options": ["List", "Ignore"]
            })

    return jsonify(notifications), 200

@retailer_bp.route("/requests/<int:request_id>/approve", methods=["POST"])
@jwt_required()
def approve_request(request_id):
    current_user_email = get_jwt_identity()
    user = User.query.filter_by(email=current_user_email).first()

    if not user:
        return jsonify({"error": "User not found"}), 404

    request = FoodRequest.query.filter_by(id=request_id).first()
    if not request or request.inventory_item.user_id != user.id or request.status != "pending":
        return jsonify({"error": "Request not found or already processed"}), 404

    request.status = "approved"
    request.inventory_item.food.status = "Approved"
    db.session.commit()

    return jsonify({"message": "Request approved"}), 200

@retailer_bp.route("/requests/<int:request_id>/ignore", methods=["POST"])
@jwt_required()
def ignore_request(request_id):
    current_user_email = get_jwt_identity()
    user = User.query.filter_by(email=current_user_email).first()

    if not user:
        return jsonify({"error": "User not found"}), 404

    request = FoodRequest.query.filter_by(id=request_id).first()
    if not request or request.inventory_item.user_id != user.id or request.status != "pending":
        return jsonify({"error": "Request not found or already processed"}), 404

    request.status = "ignored"
    db.session.commit()

    return jsonify({"message": "Request ignored"}), 200

# foodloop_app/retailer_routes.py
# ... (existing imports and blueprint definition remain the same)

@retailer_bp.route("/item/remove/<int:item_id>", methods=["DELETE"])
@jwt_required()
def remove_inventory_item(item_id):
    current_user_email = get_jwt_identity()
    user = User.query.filter_by(email=current_user_email).first()

    if not user or "Retailer" not in [role.name for role in user.roles]:
        return jsonify({"error": "User not found or not a retailer"}), 404

    item = InventoryItem.query.filter_by(id=item_id, user_id=user.id).first()
    if not item:
        return jsonify({"error": "Inventory item not found"}), 404

    try:
        db.session.delete(item)
        db.session.commit()
        return jsonify({"message": "Item removed successfully"}), 200
    except Exception as e:
        db.session.rollback()
        return jsonify({"error": str(e)}), 400

@retailer_bp.route("/food/<int:id>/ignore", methods=["POST"])
@jwt_required()
def ignore_notification(id):
    current_user_email = get_jwt_identity()
    user = User.query.filter_by(email=current_user_email).first()

    if not user or "Retailer" not in [role.name for role in user.roles]:
        return jsonify({"error": "User not found or not a retailer"}), 404

    item = InventoryItem.query.filter_by(id=id, user_id=user.id).join(Food).first()
    if not item or item.food.status not in ["Selling", "Listing"]:
        return jsonify({"error": "Item not found or not eligible for ignore"}), 404

    # No status change; simply acknowledge the ignore action
    # Optionally, log this action in a notifications table if implemented
    return jsonify({"message": "Notification ignored"}), 200
